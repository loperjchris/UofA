#ifndef _LIBDISK_H
#define _LIBDISK_H

extern int Disk_Create(char *dir, unsigned int unit, unsigned int tracks);

#endif