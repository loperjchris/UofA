#include "phase1.h"

int P2_Startup(void *notused) 
{
    USLOSS_Console("P2_Startup\n");
    return 0;
}

void test_setup(int argc, char **argv) {
    // Do nothing.
}

void test_cleanup(int argc, char **argv) {
    // Do nothing.
}