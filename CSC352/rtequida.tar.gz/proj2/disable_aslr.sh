#!/bin/sh

setarch x86_64 -R /bin/bash
